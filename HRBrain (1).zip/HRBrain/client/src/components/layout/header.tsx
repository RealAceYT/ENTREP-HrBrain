import { useState } from "react";
import { Bell, Menu, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  onToggleMobileMenu: () => void;
}

export function Header({ onToggleMobileMenu }: HeaderProps) {
  const [notificationCount] = useState(3);

  return (
    <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow">
      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="sm"
        className="px-4 border-r border-gray-200 text-gray-500 lg:hidden"
        onClick={onToggleMobileMenu}
        data-testid="button-toggle-mobile-menu"
      >
        <span className="sr-only">Open sidebar</span>
        <Menu className="h-6 w-6" />
      </Button>
      
      {/* Header content */}
      <div className="flex-1 px-4 flex justify-between items-center">
        <div className="flex-1 flex">
          <div className="w-full flex lg:ml-0">
            <div className="relative w-full text-gray-400 focus-within:text-gray-600 max-w-lg">
              <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none">
                <Search className="h-5 w-5" />
              </div>
              <Input
                className="block w-full h-full pl-8 pr-3 py-2 border-0 text-gray-900 placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-2 focus:ring-ace-blue focus:border-transparent sm:text-sm rounded-md bg-gray-50"
                placeholder="Search employees, complaints, or meetings..."
                type="search"
                data-testid="input-search"
              />
            </div>
          </div>
        </div>
        <div className="ml-4 flex items-center lg:ml-6">
          {/* Notifications */}
          <Button
            variant="ghost"
            size="sm"
            className="bg-white p-1 rounded-full text-gray-400 hover:text-gray-500 relative"
            data-testid="button-notifications"
          >
            <span className="sr-only">View notifications</span>
            <Bell className="h-6 w-6" />
            {notificationCount > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 bg-ace-red rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-medium">
                  {notificationCount}
                </span>
              </span>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
