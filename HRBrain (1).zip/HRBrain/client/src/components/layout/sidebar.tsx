import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Bot, Gauge, MessageSquare, Calendar, Brain, BarChart3, Users, X, Settings, LogOut, Shield } from "lucide-react";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  onClose?: () => void;
}

const baseNavigation = [
  { name: "Dashboard", href: "/", icon: Gauge },
  { name: "Complaints & Requests", href: "/complaints", icon: MessageSquare },
  { name: "Meeting Scheduler", href: "/meetings", icon: Calendar },
  { name: "AI Scenarios", href: "/scenarios", icon: Brain },
  { name: "Employee Portal", href: "/employee-portal", icon: Users },
];

const adminNavigation = [
  { name: "Admin Dashboard", href: "/admin", icon: Shield },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
];

export function Sidebar({ onClose }: SidebarProps) {
  const [location] = useLocation();
  const { user, logout, isHRManager } = useAuth();
  
  const navigation = [...baseNavigation, ...(isHRManager ? adminNavigation : [])];

  return (
    <div className="flex flex-col w-64">
      <div className="flex flex-col flex-grow pt-5 pb-4 overflow-y-auto bg-white border-r border-gray-200">
        {/* Logo and Brand */}
        <div className="flex items-center flex-shrink-0 px-4">
          {onClose && (
            <button
              onClick={onClose}
              className="lg:hidden mr-3 p-1 rounded-md text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-ace-blue"
              data-testid="button-close-sidebar"
            >
              <X className="h-6 w-6" />
            </button>
          )}
          <div className="flex items-center">
            <div className="w-10 h-10 bg-ace-blue rounded-lg flex items-center justify-center">
              <Bot className="text-white text-lg" />
            </div>
            <div className="ml-3">
              <h1 className="text-xl font-semibold text-gray-900">A.C.E</h1>
              <p className="text-sm text-ace-gray">HR Assistant</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="mt-8">
          <div className="px-2 space-y-1">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href || 
                (item.href !== "/" && location.startsWith(item.href));
              
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "group flex items-center px-2 py-2 text-sm font-medium rounded-md",
                    isActive
                      ? "bg-ace-blue text-white"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                  )}
                  data-testid={`link-${item.name.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  <Icon 
                    className={cn(
                      "mr-3 flex-shrink-0 h-6 w-6",
                      isActive 
                        ? "text-white" 
                        : "text-gray-400 group-hover:text-gray-500"
                    )}
                  />
                  {item.name}
                </Link>
              );
            })}
          </div>
        </div>

        {/* User Profile */}
        <div className="mt-auto border-t border-gray-200">
          <div className="p-4 space-y-2">
            <div className="flex items-center">
              <div className="w-9 h-9 bg-ace-blue rounded-full flex items-center justify-center">
                <Users className="text-white h-5 w-5" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-700">
                  {user?.name || "User"}
                </p>
                <p className="text-xs font-medium text-gray-500 capitalize">
                  {user?.role?.replace("_", " ") || "Employee"}
                </p>
              </div>
            </div>
            
            <div className="pt-2 space-y-1">
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start text-gray-600 hover:text-gray-900 hover:bg-gray-50"
                data-testid="button-settings"
              >
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
                data-testid="button-logout"
              >
                <LogOut className="mr-2 h-4 w-4" />
                Sign out
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
