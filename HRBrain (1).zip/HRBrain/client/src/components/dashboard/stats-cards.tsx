import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, CheckCircle, Calendar, Brain } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Stats {
  activeIssues: number;
  resolvedThisMonth: number;
  upcomingMeetings: number;
  aiRecommendations: number;
}

export function StatsCards() {
  const { data: stats, isLoading } = useQuery<Stats>({
    queryKey: ["/api/analytics/stats"],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-5">
              <Skeleton className="h-16 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Active Issues",
      value: stats?.activeIssues || 0,
      icon: AlertTriangle,
      iconBg: "bg-ace-blue",
      iconColor: "text-white",
      action: "View all",
      href: "/complaints"
    },
    {
      title: "Resolved This Month", 
      value: stats?.resolvedThisMonth || 0,
      icon: CheckCircle,
      iconBg: "bg-ace-green",
      iconColor: "text-white",
      change: "+12% from last month",
      changeColor: "text-ace-green"
    },
    {
      title: "Upcoming Meetings",
      value: stats?.upcomingMeetings || 0,
      icon: Calendar,
      iconBg: "bg-purple-500",
      iconColor: "text-white", 
      action: "Schedule new",
      href: "/meetings"
    },
    {
      title: "AI Recommendations",
      value: stats?.aiRecommendations || 0,
      icon: Brain,
      iconBg: "bg-orange-500",
      iconColor: "text-white",
      action: "Review",
      href: "/scenarios"
    }
  ];

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index} className="bg-white overflow-hidden shadow">
            <CardContent className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className={`w-8 h-8 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                    <Icon className={`h-5 w-5 ${card.iconColor}`} />
                  </div>
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      {card.title}
                    </dt>
                    <dd className="text-lg font-medium text-gray-900" data-testid={`stat-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
                      {card.value}
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
            <div className="bg-gray-50 px-5 py-3">
              <div className="text-sm">
                {card.action && (
                  <a 
                    href={card.href} 
                    className="font-medium text-ace-blue hover:text-blue-600"
                    data-testid={`link-${card.action.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {card.action}
                  </a>
                )}
                {card.change && (
                  <span className={`font-medium ${card.changeColor}`}>
                    {card.change}
                  </span>
                )}
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
