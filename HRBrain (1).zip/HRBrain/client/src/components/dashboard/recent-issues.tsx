import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Filter } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { Complaint } from "@shared/schema";

export function RecentIssues() {
  const { data: complaints, isLoading } = useQuery<Complaint[]>({
    queryKey: ["/api/complaints"],
  });

  if (isLoading) {
    return (
      <Card className="bg-white shadow">
        <CardHeader>
          <CardTitle>Recent Issues</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const recentComplaints = complaints?.slice(0, 3) || [];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityDot = (priority: string) => {
    switch (priority) {
      case "urgent":
      case "high":
        return "bg-ace-red";
      case "medium":
        return "bg-orange-400";
      case "low":
        return "bg-ace-green";
      default:
        return "bg-gray-400";
    }
  };

  return (
    <Card className="bg-white shadow">
      <CardHeader className="border-b border-gray-200">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-medium text-gray-900">
            Recent Issues
          </CardTitle>
          <div className="flex space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-ace-blue hover:text-blue-600"
              data-testid="button-filter-issues"
            >
              <Filter className="mr-1 h-4 w-4" />
              Filter
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {recentComplaints.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-gray-500">No recent issues found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {recentComplaints.map((complaint) => (
              <div 
                key={complaint.id} 
                className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50 border border-gray-200"
                data-testid={`issue-${complaint.id}`}
              >
                <div className="flex-shrink-0">
                  <div className={`w-2 h-2 ${getPriorityDot(complaint.priority)} rounded-full mt-2`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900" data-testid={`text-issue-title-${complaint.id}`}>
                        {complaint.title}
                      </p>
                      <p className="text-sm text-gray-500 mt-1" data-testid={`text-issue-description-${complaint.id}`}>
                        {complaint.description.length > 100 
                          ? `${complaint.description.substring(0, 100)}...`
                          : complaint.description
                        }
                      </p>
                      <div className="mt-2 flex items-center space-x-4">
                        <span className="text-xs text-gray-500" data-testid={`text-issue-date-${complaint.id}`}>
                          {new Date(complaint.createdAt!).toLocaleDateString()}
                        </span>
                        <span className="text-xs text-gray-500">
                          {complaint.category}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                      <Badge 
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(complaint.priority)}`}
                        data-testid={`badge-priority-${complaint.id}`}
                      >
                        {complaint.priority} Priority
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs text-ace-blue hover:text-blue-600"
                        data-testid={`button-view-details-${complaint.id}`}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      <div className="px-6 py-3 bg-gray-50 border-t border-gray-200">
        <div className="flex justify-between items-center">
          <p className="text-sm text-gray-700">
            Showing {recentComplaints.length} of {complaints?.length || 0} issues
          </p>
          <Button
            variant="ghost"
            size="sm"
            className="text-ace-blue hover:text-blue-600"
            data-testid="button-view-all-issues"
          >
            View all issues
          </Button>
        </div>
      </div>
    </Card>
  );
}
