import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bot, Lightbulb, TrendingUp, Play, FileText, Smile, Send } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export function AiAssistantPanel() {
  const [question, setQuestion] = useState("");
  const [chatResponse, setChatResponse] = useState("");

  const chatMutation = useMutation({
    mutationFn: async (question: string) => {
      const response = await apiRequest("POST", "/api/ai/chat", { question });
      return response.json();
    },
    onSuccess: (data) => {
      setChatResponse(data.response);
      setQuestion("");
    },
  });

  const handleAskQuestion = () => {
    if (question.trim()) {
      chatMutation.mutate(question);
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Assistant Panel */}
      <Card className="bg-white shadow">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-ace-blue rounded-lg flex items-center justify-center mr-3">
              <Bot className="text-white h-5 w-5" />
            </div>
            <CardTitle className="text-lg font-medium text-gray-900">
              A.C.E Assistant
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {/* AI Recommendations */}
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <Lightbulb className="text-blue-400 h-5 w-5" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-blue-800">
                    AI Recommendation
                  </h4>
                  <p className="text-sm text-blue-700 mt-1">
                    Consider implementing a structured feedback system to address the recent increase in workplace concerns.
                  </p>
                  <div className="mt-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs font-medium text-blue-600 hover:text-blue-500 p-0 h-auto"
                      data-testid="button-implement-recommendation"
                    >
                      Implement Suggestion
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <TrendingUp className="text-green-400 h-5 w-5" />
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium text-green-800">
                    Trend Alert
                  </h4>
                  <p className="text-sm text-green-700 mt-1">
                    15% increase in schedule flexibility requests this month. Consider reviewing current policies.
                  </p>
                  <div className="mt-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs font-medium text-green-600 hover:text-green-500 p-0 h-auto"
                      data-testid="button-view-trend-details"
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Chat with A.C.E */}
          <div className="mt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Ask A.C.E</h4>
            <div className="space-y-3">
              <div className="flex space-x-2">
                <Input
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="Ask A.C.E about HR policies, procedures..."
                  className="flex-1"
                  onKeyPress={(e) => e.key === "Enter" && handleAskQuestion()}
                  data-testid="input-ai-question"
                />
                <Button
                  onClick={handleAskQuestion}
                  disabled={!question.trim() || chatMutation.isPending}
                  size="sm"
                  className="bg-ace-blue hover:bg-ace-blue/90"
                  data-testid="button-ask-ai"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
              
              {chatResponse && (
                <div className="bg-gray-50 border rounded-lg p-3">
                  <p className="text-sm text-gray-700" data-testid="text-ai-response">
                    {chatResponse}
                  </p>
                </div>
              )}
              
              {chatMutation.isPending && (
                <div className="bg-gray-50 border rounded-lg p-3">
                  <p className="text-sm text-gray-500">A.C.E is thinking...</p>
                </div>
              )}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="mt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Quick Actions</h4>
            <div className="space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                data-testid="button-run-scenario"
              >
                <Play className="text-gray-400 mr-2 h-4 w-4" />
                Run Scenario Simulation
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                data-testid="button-generate-report"
              >
                <FileText className="text-gray-400 mr-2 h-4 w-4" />
                Generate Compliance Report
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                data-testid="button-analyze-sentiment"
              >
                <Smile className="text-gray-400 mr-2 h-4 w-4" />
                Analyze Employee Sentiment
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Today's Schedule */}
      <Card className="bg-white shadow">
        <CardHeader className="border-b border-gray-200">
          <CardTitle className="text-lg font-medium text-gray-900">
            Today's Schedule
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-3">
            {/* Sample meetings - in a real app this would come from API */}
            <div className="flex items-center space-x-3">
              <div className="w-2 h-8 bg-ace-blue rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900" data-testid="text-meeting-title-1">
                  Team Check-in
                </p>
                <p className="text-xs text-gray-500" data-testid="text-meeting-time-1">
                  2:00 PM - 2:30 PM
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-ace-blue hover:text-blue-600"
                data-testid="button-join-meeting-1"
              >
                Join
              </Button>
            </div>

            <div className="flex items-center space-x-3">
              <div className="w-2 h-8 bg-orange-400 rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900" data-testid="text-meeting-title-2">
                  HR Policy Review
                </p>
                <p className="text-xs text-gray-500" data-testid="text-meeting-time-2">
                  4:00 PM - 4:45 PM
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-ace-blue hover:text-blue-600"
                data-testid="button-join-meeting-2"
              >
                Join
              </Button>
            </div>

            <div className="flex items-center space-x-3">
              <div className="w-2 h-8 bg-ace-green rounded-full"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900" data-testid="text-meeting-title-3">
                  Employee Check-in
                </p>
                <p className="text-xs text-gray-500" data-testid="text-meeting-time-3">
                  5:30 PM - 6:00 PM
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-ace-blue hover:text-blue-600"
                data-testid="button-join-meeting-3"
              >
                Join
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
