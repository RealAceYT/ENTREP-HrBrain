import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Hand, Calendar, Bot } from "lucide-react";

export function EmployeePortalActions() {
  const actions = [
    {
      title: "Submit Complaint",
      description: "Report workplace issues or concerns with complete confidentiality.",
      icon: AlertTriangle,
      iconBg: "bg-ace-blue",
      href: "/complaints",
      testId: "button-submit-complaint"
    },
    {
      title: "Make Request", 
      description: "Request time off, schedule changes, or other HR services.",
      icon: Hand,
      iconBg: "bg-ace-green",
      href: "/employee-portal",
      testId: "button-make-request"
    },
    {
      title: "Schedule Meeting",
      description: "Book a meeting with HR representatives or counselors.",
      icon: Calendar,
      iconBg: "bg-purple-500",
      href: "/meetings",
      testId: "button-schedule-meeting"
    },
    {
      title: "Ask A.C.E",
      description: "Get instant answers to HR questions and policy information.",
      icon: Bot,
      iconBg: "bg-orange-500",
      href: "/",
      testId: "button-ask-ace"
    }
  ];

  return (
    <Card className="bg-white shadow">
      <CardHeader className="border-b border-gray-200">
        <CardTitle className="text-lg font-medium text-gray-900">
          Employee Portal Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {actions.map((action) => {
            const Icon = action.icon;
            return (
              <Link
                key={action.title}
                href={action.href}
                className="relative group bg-gray-50 p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-ace-blue rounded-lg hover:bg-gray-100 transition-colors"
                data-testid={action.testId}
              >
                <div>
                  <span className={`rounded-lg inline-flex p-3 ${action.iconBg} text-white`}>
                    <Icon className="h-6 w-6" />
                  </span>
                </div>
                <div className="mt-8">
                  <h3 className="text-lg font-medium text-gray-900">
                    {action.title}
                  </h3>
                  <p className="mt-2 text-sm text-gray-500">
                    {action.description}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
