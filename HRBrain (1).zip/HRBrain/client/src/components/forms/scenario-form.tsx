import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertScenarioSchema } from "@shared/schema";

const scenarioFormSchema = insertScenarioSchema.extend({
  category: z.enum(["conflict_resolution", "policy_violation", "performance", "harassment"]),
});

type ScenarioFormData = z.infer<typeof scenarioFormSchema>;

interface ScenarioFormProps {
  onClose: () => void;
}

export function ScenarioForm({ onClose }: ScenarioFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ScenarioFormData>({
    resolver: zodResolver(scenarioFormSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "conflict_resolution",
      scenario: "",
      createdBy: "default-user-id", // In a real app, this would come from auth
    },
  });

  const createScenarioMutation = useMutation({
    mutationFn: async (data: ScenarioFormData) => {
      const response = await apiRequest("POST", "/api/scenarios", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/scenarios"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/stats"] });
      toast({
        title: "Success",
        description: "Scenario created successfully. A.C.E is analyzing it now.",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create scenario. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: ScenarioFormData) => {
    setIsSubmitting(true);
    try {
      await createScenarioMutation.mutateAsync(data);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Scenario Title *</FormLabel>
              <FormControl>
                <Input
                  placeholder="Brief title for the scenario"
                  {...field}
                  data-testid="input-scenario-title"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="category"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Category *</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-scenario-category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="conflict_resolution">Conflict Resolution</SelectItem>
                  <SelectItem value="policy_violation">Policy Violation</SelectItem>
                  <SelectItem value="performance">Performance Issue</SelectItem>
                  <SelectItem value="harassment">Harassment</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description *</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Brief description of what this scenario is about"
                  className="min-h-[80px]"
                  {...field}
                  data-testid="textarea-scenario-description"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="scenario"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Scenario Details *</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Describe the detailed scenario you want A.C.E to analyze. Include context, people involved, actions taken, timeline, and any relevant background information."
                  className="min-h-[150px]"
                  {...field}
                  data-testid="textarea-scenario-details"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="text-sm font-medium text-blue-800">How A.C.E Analysis Works</h4>
          <p className="text-sm text-blue-700 mt-1">
            A.C.E will analyze your scenario and provide:
          </p>
          <ul className="text-sm text-blue-700 mt-2 space-y-1">
            <li>• Unbiased assessment of the situation</li>
            <li>• Risk level evaluation</li>
            <li>• Recommended actions and next steps</li>
            <li>• Compliance considerations</li>
            <li>• Potential outcomes and consequences</li>
          </ul>
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            data-testid="button-cancel-scenario"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSubmitting}
            className="bg-ace-blue hover:bg-ace-blue/90"
            data-testid="button-create-scenario"
          >
            {isSubmitting ? "Creating..." : "Create & Analyze"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
