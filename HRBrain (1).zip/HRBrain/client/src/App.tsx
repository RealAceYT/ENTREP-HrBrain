import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/auth-context";
import { AuthPage } from "@/components/auth/auth-page";
import { AdminDashboard } from "@/components/admin/admin-dashboard";
import Dashboard from "@/pages/dashboard";
import Complaints from "@/pages/complaints";
import Meetings from "@/pages/meetings";
import Scenarios from "@/pages/scenarios";
import Analytics from "@/pages/analytics";
import EmployeePortal from "@/pages/employee-portal";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ component: Component, adminOnly = false, ...props }: any) {
  const { isAuthenticated, isHRManager, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }
  
  if (!isAuthenticated) {
    return <AuthPage onAuthenticated={() => {}} />;
  }
  
  if (adminOnly && !isHRManager) {
    return <div className="flex items-center justify-center min-h-screen text-red-600">Access denied. HR Manager role required.</div>;
  }
  
  return <Component {...props} />;
}

function Router() {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (!isAuthenticated) {
    return <AuthPage onAuthenticated={() => {}} />;
  }

  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/admin" component={() => <ProtectedRoute component={AdminDashboard} adminOnly={true} />} />
      <Route path="/complaints" component={Complaints} />
      <Route path="/meetings" component={Meetings} />
      <Route path="/scenarios" component={Scenarios} />
      <Route path="/analytics" component={() => <ProtectedRoute component={Analytics} adminOnly={true} />} />
      <Route path="/employee-portal" component={EmployeePortal} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
