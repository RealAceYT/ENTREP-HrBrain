import { MainLayout } from "@/components/layout/main-layout";
import { ComplaintForm } from "@/components/forms/complaint-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { useState } from "react";
import type { Complaint } from "@shared/schema";

export default function Complaints() {
  const [showForm, setShowForm] = useState(false);
  
  const { data: complaints, isLoading } = useQuery<Complaint[]>({
    queryKey: ["/api/complaints"],
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "bg-green-100 text-green-800";
      case "in_progress":
        return "bg-blue-100 text-blue-800";
      case "open":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page header */}
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Complaints & Requests
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                Manage and track all employee complaints and requests
              </p>
            </div>
            <div className="mt-5 flex lg:mt-0 lg:ml-4">
              <Button
                onClick={() => setShowForm(true)}
                className="inline-flex items-center bg-ace-blue hover:bg-ace-blue/90"
                data-testid="button-new-complaint"
              >
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                New Complaint
              </Button>
            </div>
          </div>

          {/* Complaint Form Modal */}
          {showForm && (
            <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
              <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                <div className="mt-3">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    Submit New Complaint
                  </h3>
                  <ComplaintForm onClose={() => setShowForm(false)} />
                </div>
              </div>
            </div>
          )}

          {/* Complaints List */}
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>All Complaints</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <p>Loading complaints...</p>
                ) : !complaints || complaints.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No complaints found</p>
                    <Button
                      onClick={() => setShowForm(true)}
                      className="mt-4 bg-ace-blue hover:bg-ace-blue/90"
                      data-testid="button-create-first-complaint"
                    >
                      Create First Complaint
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {complaints.map((complaint) => (
                      <div
                        key={complaint.id}
                        className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50"
                        data-testid={`complaint-${complaint.id}`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="text-lg font-medium text-gray-900" data-testid={`text-complaint-title-${complaint.id}`}>
                              {complaint.title}
                            </h3>
                            <p className="text-sm text-gray-600 mt-1" data-testid={`text-complaint-description-${complaint.id}`}>
                              {complaint.description}
                            </p>
                            <div className="mt-3 flex items-center space-x-4">
                              <Badge className={getPriorityColor(complaint.priority)} data-testid={`badge-priority-${complaint.id}`}>
                                {complaint.priority}
                              </Badge>
                              <Badge className={getStatusColor(complaint.status)} data-testid={`badge-status-${complaint.id}`}>
                                {complaint.status}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {complaint.category}
                              </span>
                              <span className="text-xs text-gray-500" data-testid={`text-complaint-date-${complaint.id}`}>
                                {new Date(complaint.createdAt!).toLocaleDateString()}
                              </span>
                            </div>
                            {complaint.aiAnalysis && (
                              <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                                <h4 className="text-sm font-medium text-blue-800">AI Analysis</h4>
                                <p className="text-sm text-blue-700 mt-1" data-testid={`text-ai-analysis-${complaint.id}`}>
                                  {complaint.aiAnalysis}
                                </p>
                                {complaint.sentimentScore && (
                                  <p className="text-xs text-blue-600 mt-1">
                                    Sentiment Score: {complaint.sentimentScore}/5
                                  </p>
                                )}
                              </div>
                            )}
                          </div>
                          <div className="ml-4">
                            <Button
                              variant="outline"
                              size="sm"
                              data-testid={`button-view-complaint-${complaint.id}`}
                            >
                              View Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
