import { MainLayout } from "@/components/layout/main-layout";
import { ScenarioForm } from "@/components/forms/scenario-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Plus, Brain, AlertTriangle, CheckCircle } from "lucide-react";
import { useState } from "react";
import type { Scenario } from "@shared/schema";

export default function Scenarios() {
  const [showForm, setShowForm] = useState(false);
  
  const { data: scenarios, isLoading } = useQuery<Scenario[]>({
    queryKey: ["/api/scenarios"],
  });

  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "harassment":
        return "bg-red-100 text-red-800";
      case "conflict_resolution":
        return "bg-blue-100 text-blue-800";
      case "policy_violation":
        return "bg-orange-100 text-orange-800";
      case "performance":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page header */}
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                AI Scenario Simulation
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                Simulate workplace scenarios and get AI-powered recommendations for HR decision-making
              </p>
            </div>
            <div className="mt-5 flex lg:mt-0 lg:ml-4">
              <Button
                onClick={() => setShowForm(true)}
                className="inline-flex items-center bg-ace-blue hover:bg-ace-blue/90"
                data-testid="button-new-scenario"
              >
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                New Scenario
              </Button>
            </div>
          </div>

          {/* Scenario Form Modal */}
          {showForm && (
            <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
              <div className="relative top-10 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
                <div className="mt-3">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    Create New Scenario
                  </h3>
                  <ScenarioForm onClose={() => setShowForm(false)} />
                </div>
              </div>
            </div>
          )}

          {/* AI Scenario Info */}
          <div className="mt-8">
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-6">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <Brain className="h-8 w-8 text-ace-blue" />
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-medium text-gray-900">
                      How A.C.E Scenario Simulation Works
                    </h3>
                    <p className="mt-2 text-sm text-gray-700">
                      Describe a workplace scenario and A.C.E will analyze it using advanced AI to provide unbiased recommendations, 
                      assess risk levels, and suggest appropriate actions. This helps HR professionals make informed decisions 
                      while ensuring compliance and fairness.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Scenarios List */}
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Scenario Simulations</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <p>Loading scenarios...</p>
                ) : !scenarios || scenarios.length === 0 ? (
                  <div className="text-center py-8">
                    <Brain className="mx-auto h-12 w-12 text-gray-400" />
                    <p className="text-gray-500 mt-2">No scenarios created yet</p>
                    <Button
                      onClick={() => setShowForm(true)}
                      className="mt-4 bg-ace-blue hover:bg-ace-blue/90"
                      data-testid="button-create-first-scenario"
                    >
                      Create First Scenario
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {scenarios.map((scenario) => (
                      <div
                        key={scenario.id}
                        className="border border-gray-200 rounded-lg p-6 hover:bg-gray-50"
                        data-testid={`scenario-${scenario.id}`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="text-lg font-medium text-gray-900" data-testid={`text-scenario-title-${scenario.id}`}>
                              {scenario.title}
                            </h3>
                            <p className="text-sm text-gray-600 mt-1" data-testid={`text-scenario-description-${scenario.id}`}>
                              {scenario.description}
                            </p>
                            
                            <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                              <h4 className="text-sm font-medium text-gray-900 mb-2">Scenario Details:</h4>
                              <p className="text-sm text-gray-700" data-testid={`text-scenario-details-${scenario.id}`}>
                                {scenario.scenario}
                              </p>
                            </div>

                            {scenario.aiResponse && (
                              <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                                <div className="flex items-start">
                                  <Brain className="h-5 w-5 text-ace-blue mt-0.5 mr-2" />
                                  <div>
                                    <h4 className="text-sm font-medium text-blue-800">A.C.E Analysis</h4>
                                    <p className="text-sm text-blue-700 mt-1" data-testid={`text-ai-response-${scenario.id}`}>
                                      {scenario.aiResponse}
                                    </p>
                                    
                                    {scenario.recommendedActions && (
                                      <div className="mt-3">
                                        <h5 className="text-sm font-medium text-blue-800">Recommended Actions:</h5>
                                        <ul className="text-sm text-blue-700 mt-1 space-y-1">
                                          {JSON.parse(scenario.recommendedActions).map((action: string, index: number) => (
                                            <li key={index} className="flex items-start">
                                              <CheckCircle className="h-4 w-4 text-blue-600 mr-1 mt-0.5 flex-shrink-0" />
                                              <span>{action}</span>
                                            </li>
                                          ))}
                                        </ul>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            )}

                            <div className="mt-4 flex items-center space-x-4">
                              <Badge className={getCategoryColor(scenario.category)} data-testid={`badge-category-${scenario.id}`}>
                                {scenario.category.replace('_', ' ')}
                              </Badge>
                              {scenario.riskLevel && (
                                <Badge className={getRiskLevelColor(scenario.riskLevel)} data-testid={`badge-risk-${scenario.id}`}>
                                  {scenario.riskLevel} risk
                                </Badge>
                              )}
                              <span className="text-xs text-gray-500" data-testid={`text-scenario-date-${scenario.id}`}>
                                Created {new Date(scenario.createdAt!).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                          <div className="ml-4">
                            <Button
                              variant="outline"
                              size="sm"
                              data-testid={`button-view-scenario-${scenario.id}`}
                            >
                              View Details
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
