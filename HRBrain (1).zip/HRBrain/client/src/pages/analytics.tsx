import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { BarChart3, TrendingUp, Users, Clock, AlertTriangle, CheckCircle } from "lucide-react";
import type { Complaint, Meeting } from "@shared/schema";

interface Analytics {
  activeIssues: number;
  resolvedThisMonth: number;
  upcomingMeetings: number;
  aiRecommendations: number;
}

export default function Analytics() {
  const { data: stats } = useQuery<Analytics>({
    queryKey: ["/api/analytics/stats"],
  });

  const { data: complaints } = useQuery<Complaint[]>({
    queryKey: ["/api/complaints"],
  });

  const { data: meetings } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings"],
  });

  // Calculate additional analytics
  const categoryStats = complaints?.reduce((acc, complaint) => {
    acc[complaint.category] = (acc[complaint.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  const priorityStats = complaints?.reduce((acc, complaint) => {
    acc[complaint.priority] = (acc[complaint.priority] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  const statusStats = complaints?.reduce((acc, complaint) => {
    acc[complaint.status] = (acc[complaint.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  const recentTrends = {
    totalComplaints: complaints?.length || 0,
    averageResolutionTime: "3.2 days",
    employeeSatisfaction: "87%",
    responseRate: "95%"
  };

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page header */}
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                HR Analytics
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                Comprehensive insights and trends for HR management
              </p>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="mt-8">
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-ace-blue rounded-lg flex items-center justify-center">
                        <AlertTriangle className="h-5 w-5 text-white" />
                      </div>
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">
                          Active Issues
                        </dt>
                        <dd className="text-2xl font-semibold text-gray-900" data-testid="stat-active-issues">
                          {stats?.activeIssues || 0}
                        </dd>
                      </dl>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="text-sm text-gray-600">
                      <span className="text-ace-red font-medium">
                        {priorityStats.high || 0} high priority
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-ace-green rounded-lg flex items-center justify-center">
                        <CheckCircle className="h-5 w-5 text-white" />
                      </div>
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">
                          Resolved This Month
                        </dt>
                        <dd className="text-2xl font-semibold text-gray-900" data-testid="stat-resolved-month">
                          {stats?.resolvedThisMonth || 0}
                        </dd>
                      </dl>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="text-sm">
                      <span className="text-ace-green font-medium">+12%</span> from last month
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
                        <Users className="h-5 w-5 text-white" />
                      </div>
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">
                          Employee Engagement
                        </dt>
                        <dd className="text-2xl font-semibold text-gray-900" data-testid="stat-engagement">
                          {recentTrends.employeeSatisfaction}
                        </dd>
                      </dl>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="text-sm">
                      <span className="text-ace-green font-medium">+5%</span> improvement
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                        <Clock className="h-5 w-5 text-white" />
                      </div>
                    </div>
                    <div className="ml-5 w-0 flex-1">
                      <dl>
                        <dt className="text-sm font-medium text-gray-500 truncate">
                          Avg. Resolution Time
                        </dt>
                        <dd className="text-2xl font-semibold text-gray-900" data-testid="stat-resolution-time">
                          {recentTrends.averageResolutionTime}
                        </dd>
                      </dl>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="text-sm">
                      <span className="text-ace-green font-medium">-15%</span> faster
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Charts and Detailed Analytics */}
          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
            {/* Complaint Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Complaints by Category
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(categoryStats).map(([category, count]) => (
                    <div key={category} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-3 h-3 rounded-full mr-3 ${
                          category === 'harassment' ? 'bg-red-500' :
                          category === 'compensation' ? 'bg-blue-500' :
                          category === 'scheduling' ? 'bg-green-500' :
                          category === 'policy' ? 'bg-purple-500' :
                          'bg-gray-500'
                        }`} />
                        <span className="text-sm font-medium text-gray-700 capitalize">
                          {category}
                        </span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-sm text-gray-900 font-medium" data-testid={`stat-category-${category}`}>
                          {count}
                        </span>
                        <div className="ml-3 w-24 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-ace-blue h-2 rounded-full" 
                            style={{ width: `${(count / recentTrends.totalComplaints) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  {Object.keys(categoryStats).length === 0 && (
                    <p className="text-gray-500 text-center py-4">No data available</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Priority Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Priority Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(priorityStats).map(([priority, count]) => (
                    <div key={priority} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-3 h-3 rounded-full mr-3 ${
                          priority === 'urgent' || priority === 'high' ? 'bg-red-500' :
                          priority === 'medium' ? 'bg-yellow-500' :
                          'bg-green-500'
                        }`} />
                        <span className="text-sm font-medium text-gray-700 capitalize">
                          {priority} Priority
                        </span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-sm text-gray-900 font-medium" data-testid={`stat-priority-${priority}`}>
                          {count}
                        </span>
                        <div className="ml-3 w-24 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              priority === 'urgent' || priority === 'high' ? 'bg-red-500' :
                              priority === 'medium' ? 'bg-yellow-500' :
                              'bg-green-500'
                            }`}
                            style={{ width: `${(count / recentTrends.totalComplaints) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  {Object.keys(priorityStats).length === 0 && (
                    <p className="text-gray-500 text-center py-4">No data available</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Status Overview */}
            <Card>
              <CardHeader>
                <CardTitle>Issue Status Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(statusStats).map(([status, count]) => (
                    <div key={status} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-3 h-3 rounded-full mr-3 ${
                          status === 'resolved' ? 'bg-green-500' :
                          status === 'in_progress' ? 'bg-blue-500' :
                          status === 'open' ? 'bg-yellow-500' :
                          'bg-gray-500'
                        }`} />
                        <span className="text-sm font-medium text-gray-700 capitalize">
                          {status.replace('_', ' ')}
                        </span>
                      </div>
                      <span className="text-sm text-gray-900 font-medium" data-testid={`stat-status-${status}`}>
                        {count}
                      </span>
                    </div>
                  ))}
                  {Object.keys(statusStats).length === 0 && (
                    <p className="text-gray-500 text-center py-4">No data available</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Trends and Insights */}
            <Card>
              <CardHeader>
                <CardTitle>Key Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-blue-800">Trending Up</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      Response rate to employee concerns has improved by 8% this month
                    </p>
                  </div>
                  
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-green-800">Positive Trend</h4>
                    <p className="text-sm text-green-700 mt-1">
                      Average resolution time decreased by 15% compared to last month
                    </p>
                  </div>
                  
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-yellow-800">Watch Area</h4>
                    <p className="text-sm text-yellow-700 mt-1">
                      Scheduling requests increased by 20% - consider policy review
                    </p>
                  </div>

                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-purple-800">A.C.E Impact</h4>
                    <p className="text-sm text-purple-700 mt-1">
                      AI recommendations implemented in 78% of cases with successful outcomes
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
