import { MainLayout } from "@/components/layout/main-layout";
import { EmployeeRequestForm } from "@/components/forms/employee-request-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Plus, User, Clock, MessageSquare, Calendar, HelpCircle } from "lucide-react";
import { useState } from "react";
import type { Complaint } from "@shared/schema";

export default function EmployeePortal() {
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [activeTab, setActiveTab] = useState<'requests' | 'complaints' | 'help'>('requests');
  
  // In a real app, this would filter by the current user's ID
  const { data: myComplaints } = useQuery<Complaint[]>({
    queryKey: ["/api/complaints"],
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
      case "high":
        return "bg-red-100 text-red-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "bg-green-100 text-green-800";
      case "in_progress":
        return "bg-blue-100 text-blue-800";
      case "open":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const quickActions = [
    {
      title: "Request Time Off",
      description: "Submit vacation, sick leave, or personal time requests",
      icon: Calendar,
      action: () => setShowRequestForm(true),
      testId: "button-request-time-off"
    },
    {
      title: "Schedule Change",
      description: "Request modifications to your work schedule",
      icon: Clock,
      action: () => setShowRequestForm(true),
      testId: "button-schedule-change"
    },
    {
      title: "HR Question",
      description: "Ask questions about policies, benefits, or procedures",
      icon: HelpCircle,
      action: () => setActiveTab('help'),
      testId: "button-hr-question"
    },
    {
      title: "Report Issue",
      description: "Submit a complaint or concern confidentially",
      icon: MessageSquare,
      action: () => setActiveTab('complaints'),
      testId: "button-report-issue"
    }
  ];

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page header */}
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Employee Portal
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                Self-service portal for HR requests, complaints, and information
              </p>
            </div>
            <div className="mt-5 flex lg:mt-0 lg:ml-4">
              <Button
                onClick={() => setShowRequestForm(true)}
                className="inline-flex items-center bg-ace-blue hover:bg-ace-blue/90"
                data-testid="button-new-request"
              >
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                New Request
              </Button>
            </div>
          </div>

          {/* Request Form Modal */}
          {showRequestForm && (
            <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
              <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                <div className="mt-3">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    Submit New Request
                  </h3>
                  <EmployeeRequestForm onClose={() => setShowRequestForm(false)} />
                </div>
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {quickActions.map((action) => {
                    const Icon = action.icon;
                    return (
                      <button
                        key={action.title}
                        onClick={action.action}
                        className="relative group bg-gray-50 p-6 focus-within:ring-2 focus-within:ring-inset focus-within:ring-ace-blue rounded-lg hover:bg-gray-100 transition-colors text-left"
                        data-testid={action.testId}
                      >
                        <div>
                          <span className="rounded-lg inline-flex p-3 bg-ace-blue text-white">
                            <Icon className="h-6 w-6" />
                          </span>
                        </div>
                        <div className="mt-8">
                          <h3 className="text-lg font-medium text-gray-900">
                            {action.title}
                          </h3>
                          <p className="mt-2 text-sm text-gray-500">
                            {action.description}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <div className="mt-8">
            <div className="border-b border-gray-200">
              <nav className="-mb-px flex space-x-8">
                <button
                  onClick={() => setActiveTab('requests')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'requests'
                      ? 'border-ace-blue text-ace-blue'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                  data-testid="tab-requests"
                >
                  My Requests
                </button>
                <button
                  onClick={() => setActiveTab('complaints')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'complaints'
                      ? 'border-ace-blue text-ace-blue'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                  data-testid="tab-complaints"
                >
                  My Issues
                </button>
                <button
                  onClick={() => setActiveTab('help')}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'help'
                      ? 'border-ace-blue text-ace-blue'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                  data-testid="tab-help"
                >
                  Help & FAQ
                </button>
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          <div className="mt-6">
            {activeTab === 'requests' && (
              <Card>
                <CardHeader>
                  <CardTitle>My Requests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <Calendar className="mx-auto h-12 w-12 text-gray-400" />
                    <p className="text-gray-500 mt-2">No requests submitted yet</p>
                    <Button
                      onClick={() => setShowRequestForm(true)}
                      className="mt-4 bg-ace-blue hover:bg-ace-blue/90"
                      data-testid="button-submit-first-request"
                    >
                      Submit Your First Request
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'complaints' && (
              <Card>
                <CardHeader>
                  <CardTitle>My Issues</CardTitle>
                </CardHeader>
                <CardContent>
                  {!myComplaints || myComplaints.length === 0 ? (
                    <div className="text-center py-8">
                      <MessageSquare className="mx-auto h-12 w-12 text-gray-400" />
                      <p className="text-gray-500 mt-2">No issues reported</p>
                      <p className="text-xs text-gray-400 mt-1">
                        If you need to report an issue, use the "Report Issue" quick action above
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {myComplaints.slice(0, 5).map((complaint) => (
                        <div
                          key={complaint.id}
                          className="border border-gray-200 rounded-lg p-4"
                          data-testid={`my-complaint-${complaint.id}`}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="text-sm font-medium text-gray-900" data-testid={`text-my-complaint-title-${complaint.id}`}>
                                {complaint.title}
                              </h3>
                              <p className="text-sm text-gray-600 mt-1">
                                {complaint.description.length > 100 
                                  ? `${complaint.description.substring(0, 100)}...`
                                  : complaint.description
                                }
                              </p>
                              <div className="mt-3 flex items-center space-x-3">
                                <Badge className={getStatusColor(complaint.status)} data-testid={`badge-my-status-${complaint.id}`}>
                                  {complaint.status}
                                </Badge>
                                <Badge className={getPriorityColor(complaint.priority)}>
                                  {complaint.priority}
                                </Badge>
                                <span className="text-xs text-gray-500">
                                  {new Date(complaint.createdAt!).toLocaleDateString()}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {activeTab === 'help' && (
              <Card>
                <CardHeader>
                  <CardTitle>Help & Frequently Asked Questions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="text-sm font-medium text-blue-800 mb-2">Ask A.C.E</h4>
                      <p className="text-sm text-blue-700 mb-3">
                        Get instant answers to HR questions using our AI assistant
                      </p>
                      <Button size="sm" className="bg-ace-blue hover:bg-ace-blue/90" data-testid="button-ask-ace-help">
                        Chat with A.C.E
                      </Button>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-lg font-medium text-gray-900">Common Questions</h4>
                      
                      <div className="space-y-3">
                        <details className="group">
                          <summary className="flex justify-between items-center font-medium cursor-pointer list-none">
                            <span>How do I request time off?</span>
                            <span className="transition group-open:rotate-180">
                              <svg fill="none" height="24" shape-rendering="geometricPrecision" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" viewBox="0 0 24 24" width="24"><path d="m6 9 6 6 6-6"></path></svg>
                            </span>
                          </summary>
                          <p className="text-gray-600 mt-3 group-open:animate-fadeIn">
                            Use the "Request Time Off" quick action above or submit a new request through the employee portal. Include your desired dates and reason for the request.
                          </p>
                        </details>

                        <details className="group">
                          <summary className="flex justify-between items-center font-medium cursor-pointer list-none">
                            <span>How can I report a workplace issue?</span>
                            <span className="transition group-open:rotate-180">
                              <svg fill="none" height="24" shape-rendering="geometricPrecision" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" viewBox="0 0 24 24" width="24"><path d="m6 9 6 6 6-6"></path></svg>
                            </span>
                          </summary>
                          <p className="text-gray-600 mt-3 group-open:animate-fadeIn">
                            You can report issues through the complaints system. All reports are treated confidentially and you have the option to submit anonymously.
                          </p>
                        </details>

                        <details className="group">
                          <summary className="flex justify-between items-center font-medium cursor-pointer list-none">
                            <span>What are my benefits?</span>
                            <span className="transition group-open:rotate-180">
                              <svg fill="none" height="24" shape-rendering="geometricPrecision" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" viewBox="0 0 24 24" width="24"><path d="m6 9 6 6 6-6"></path></svg>
                            </span>
                          </summary>
                          <p className="text-gray-600 mt-3 group-open:animate-fadeIn">
                            For detailed benefits information, please contact HR directly or ask A.C.E for specific questions about your benefits package.
                          </p>
                        </details>

                        <details className="group">
                          <summary className="flex justify-between items-center font-medium cursor-pointer list-none">
                            <span>How do I schedule a meeting with HR?</span>
                            <span className="transition group-open:rotate-180">
                              <svg fill="none" height="24" shape-rendering="geometricPrecision" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" viewBox="0 0 24 24" width="24"><path d="m6 9 6 6 6-6"></path></svg>
                            </span>
                          </summary>
                          <p className="text-gray-600 mt-3 group-open:animate-fadeIn">
                            You can schedule meetings through the Meeting Scheduler or submit a request for HR to contact you through the employee portal.
                          </p>
                        </details>
                      </div>
                    </div>

                    <div className="border-t border-gray-200 pt-6">
                      <h4 className="text-lg font-medium text-gray-900 mb-3">Need More Help?</h4>
                      <div className="space-y-2">
                        <p className="text-sm text-gray-600">
                          <strong>Email:</strong> hr@company.com
                        </p>
                        <p className="text-sm text-gray-600">
                          <strong>Phone:</strong> (555) 123-4567
                        </p>
                        <p className="text-sm text-gray-600">
                          <strong>Office Hours:</strong> Monday - Friday, 9:00 AM - 5:00 PM
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
