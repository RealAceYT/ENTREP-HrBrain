import { MainLayout } from "@/components/layout/main-layout";
import { MeetingForm } from "@/components/forms/meeting-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Plus, Calendar, Clock, Users } from "lucide-react";
import { useState } from "react";
import type { Meeting } from "@shared/schema";

export default function Meetings() {
  const [showForm, setShowForm] = useState(false);
  
  const { data: meetings, isLoading } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "scheduled":
        return "bg-blue-100 text-blue-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "one_on_one":
        return "bg-purple-100 text-purple-800";
      case "team_meeting":
        return "bg-blue-100 text-blue-800";
      case "counseling":
        return "bg-orange-100 text-orange-800";
      case "investigation":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page header */}
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                Meeting Scheduler
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                Schedule and manage meetings with employees and counselors
              </p>
            </div>
            <div className="mt-5 flex lg:mt-0 lg:ml-4">
              <Button
                onClick={() => setShowForm(true)}
                className="inline-flex items-center bg-ace-blue hover:bg-ace-blue/90"
                data-testid="button-new-meeting"
              >
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                Schedule Meeting
              </Button>
            </div>
          </div>

          {/* Meeting Form Modal */}
          {showForm && (
            <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
              <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                <div className="mt-3">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    Schedule New Meeting
                  </h3>
                  <MeetingForm onClose={() => setShowForm(false)} />
                </div>
              </div>
            </div>
          )}

          {/* Meetings List */}
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>All Meetings</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <p>Loading meetings...</p>
                ) : !meetings || meetings.length === 0 ? (
                  <div className="text-center py-8">
                    <Calendar className="mx-auto h-12 w-12 text-gray-400" />
                    <p className="text-gray-500 mt-2">No meetings scheduled</p>
                    <Button
                      onClick={() => setShowForm(true)}
                      className="mt-4 bg-ace-blue hover:bg-ace-blue/90"
                      data-testid="button-schedule-first-meeting"
                    >
                      Schedule First Meeting
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {meetings.map((meeting) => (
                      <div
                        key={meeting.id}
                        className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50"
                        data-testid={`meeting-${meeting.id}`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="text-lg font-medium text-gray-900" data-testid={`text-meeting-title-${meeting.id}`}>
                              {meeting.title}
                            </h3>
                            {meeting.description && (
                              <p className="text-sm text-gray-600 mt-1" data-testid={`text-meeting-description-${meeting.id}`}>
                                {meeting.description}
                              </p>
                            )}
                            <div className="mt-3 flex items-center space-x-4">
                              <div className="flex items-center text-sm text-gray-500">
                                <Calendar className="mr-1 h-4 w-4" />
                                <span data-testid={`text-meeting-date-${meeting.id}`}>
                                  {new Date(meeting.scheduledDate).toLocaleDateString()}
                                </span>
                              </div>
                              <div className="flex items-center text-sm text-gray-500">
                                <Clock className="mr-1 h-4 w-4" />
                                <span data-testid={`text-meeting-time-${meeting.id}`}>
                                  {new Date(meeting.scheduledDate).toLocaleTimeString([], { 
                                    hour: '2-digit', 
                                    minute: '2-digit' 
                                  })}
                                </span>
                              </div>
                              <div className="flex items-center text-sm text-gray-500">
                                <Clock className="mr-1 h-4 w-4" />
                                <span>{meeting.duration} min</span>
                              </div>
                              {meeting.attendeeIds && meeting.attendeeIds.length > 0 && (
                                <div className="flex items-center text-sm text-gray-500">
                                  <Users className="mr-1 h-4 w-4" />
                                  <span>{meeting.attendeeIds.length} attendees</span>
                                </div>
                              )}
                            </div>
                            <div className="mt-3 flex items-center space-x-2">
                              <Badge className={getStatusColor(meeting.status)} data-testid={`badge-status-${meeting.id}`}>
                                {meeting.status}
                              </Badge>
                              <Badge className={getTypeColor(meeting.type)} data-testid={`badge-type-${meeting.id}`}>
                                {meeting.type.replace('_', ' ')}
                              </Badge>
                            </div>
                          </div>
                          <div className="ml-4 space-y-2">
                            <Button
                              variant="outline"
                              size="sm"
                              data-testid={`button-view-meeting-${meeting.id}`}
                            >
                              View Details
                            </Button>
                            {meeting.meetingLink && (
                              <Button
                                variant="default"
                                size="sm"
                                className="bg-ace-blue hover:bg-ace-blue/90 w-full"
                                data-testid={`button-join-meeting-${meeting.id}`}
                              >
                                Join Meeting
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
