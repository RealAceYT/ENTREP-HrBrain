import { MainLayout } from "@/components/layout/main-layout";
import { StatsCards } from "@/components/dashboard/stats-cards";
import { RecentIssues } from "@/components/dashboard/recent-issues";
import { AiAssistantPanel } from "@/components/dashboard/ai-assistant-panel";
import { EmployeePortalActions } from "@/components/dashboard/employee-portal-actions";
import { Button } from "@/components/ui/button";
import { Download, Plus, Clock } from "lucide-react";

export default function Dashboard() {
  return (
    <MainLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page header */}
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="flex-1 min-w-0">
              <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                HR Dashboard
              </h2>
              <div className="mt-1 flex flex-col sm:flex-row sm:flex-wrap sm:mt-0 sm:space-x-6">
                <div className="mt-2 flex items-center text-sm text-gray-500">
                  <Clock className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                  Last updated 2 minutes ago
                </div>
              </div>
            </div>
            <div className="mt-5 flex lg:mt-0 lg:ml-4">
              <Button
                variant="outline"
                className="inline-flex items-center"
                data-testid="button-export-report"
              >
                <Download className="-ml-1 mr-2 h-5 w-5" />
                Export Report
              </Button>
              <Button
                className="ml-3 inline-flex items-center bg-ace-blue hover:bg-ace-blue/90"
                data-testid="button-new-issue"
              >
                <Plus className="-ml-1 mr-2 h-5 w-5" />
                New Issue
              </Button>
            </div>
          </div>

          {/* Stats cards */}
          <div className="mt-8">
            <StatsCards />
          </div>

          {/* Main content grid */}
          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
            {/* Recent Issues */}
            <div className="lg:col-span-2">
              <RecentIssues />
            </div>

            {/* AI Assistant Panel */}
            <div className="lg:col-span-1">
              <AiAssistantPanel />
            </div>
          </div>

          {/* Employee Portal Section */}
          <div className="mt-8">
            <EmployeePortalActions />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
