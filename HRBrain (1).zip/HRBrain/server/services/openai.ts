import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface ComplaintAnalysis {
  category: string;
  priority: string;
  sentiment: number;
  confidence: number;
  summary: string;
  recommendations: string[];
  riskLevel: string;
}

export async function analyzeComplaint(
  title: string, 
  description: string
): Promise<ComplaintAnalysis> {
  try {
    const prompt = `
    Analyze the following HR complaint and provide a detailed assessment:
    
    Title: ${title}
    Description: ${description}
    
    Please provide your analysis in JSON format with the following structure:
    {
      "category": "one of: harassment, compensation, scheduling, policy, discrimination, safety, other",
      "priority": "one of: low, medium, high, urgent",
      "sentiment": "rating from 1-5 where 1=very negative, 5=neutral/positive",
      "confidence": "confidence score from 0-100",
      "summary": "brief 2-3 sentence summary of the complaint",
      "recommendations": ["array", "of", "specific", "action", "items"],
      "riskLevel": "one of: low, medium, high"
    }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert HR analyst. Analyze complaints objectively and provide actionable insights. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    const analysis = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      category: analysis.category || "other",
      priority: analysis.priority || "medium",
      sentiment: Math.max(1, Math.min(5, analysis.sentiment || 3)),
      confidence: Math.max(0, Math.min(100, analysis.confidence || 50)),
      summary: analysis.summary || "Unable to analyze complaint",
      recommendations: analysis.recommendations || [],
      riskLevel: analysis.riskLevel || "medium"
    };
  } catch (error) {
    console.error("Failed to analyze complaint:", error);
    return {
      category: "other",
      priority: "medium", 
      sentiment: 3,
      confidence: 0,
      summary: "Analysis failed - manual review required",
      recommendations: ["Manually review this complaint", "Assign to HR specialist"],
      riskLevel: "medium"
    };
  }
}

export async function generateScenarioResponse(scenario: string): Promise<{
  response: string;
  recommendedActions: string[];
  riskLevel: string;
}> {
  try {
    const prompt = `
    As an expert HR consultant, analyze the following workplace scenario and provide guidance:
    
    Scenario: ${scenario}
    
    Please provide your response in JSON format:
    {
      "response": "detailed analysis and explanation of the situation",
      "recommendedActions": ["specific", "actionable", "steps", "to", "take"],
      "riskLevel": "one of: low, medium, high"
    }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert HR consultant providing unbiased, professional guidance on workplace scenarios. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt,
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      response: result.response || "Unable to analyze scenario",
      recommendedActions: result.recommendedActions || ["Seek additional consultation"],
      riskLevel: result.riskLevel || "medium"
    };
  } catch (error) {
    console.error("Failed to analyze scenario:", error);
    return {
      response: "Analysis failed - please consult with HR specialist for manual review",
      recommendedActions: ["Manual review required", "Consult HR policies", "Seek legal counsel if needed"],
      riskLevel: "medium"
    };
  }
}

export async function generateHRResponse(question: string): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are A.C.E, an AI HR assistant. Provide helpful, professional responses to HR-related questions. Be concise but thorough."
        },
        {
          role: "user",
          content: question,
        },
      ],
    });

    return response.choices[0].message.content || "I apologize, but I couldn't process your question. Please try rephrasing or contact HR directly.";
  } catch (error) {
    console.error("Failed to generate HR response:", error);
    return "I'm currently unable to process your request. Please contact HR directly for assistance.";
  }
}
